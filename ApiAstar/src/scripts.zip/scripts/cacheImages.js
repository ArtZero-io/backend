require('dotenv').config({path: '/AZ/API/.env'});
let mongoose = require('mongoose');
let database = require('../../database.js');
let axios = require('axios');
let FormData = require('form-data');
let fs = require('fs');

const connectDb = () => {
  return mongoose.connect("mongodb://ArtZeroAccTest:ArtZeroAcc2022*@127.0.0.1:27071/ArtZeroDbDbPreTest", {useNewUrlParser: true});
};

connectDb().then(async () => {
  // Checking the configs before running
  let total_supply = 200;
  let image_ipfs_link = "ipfs://bafybeicuufb2745l5g5zm2fa32fydao76iur72lwaqrt7dmhzkdupmzxue/";
  let json_ipfs_link = "ipfs://QmXtnr9aEJVywiLs1keZdyiKbQwignZT3FhwKYivF15oZp/";
  let collection_address = "5EcLGySmt9Z9YqZE239CrKa7cdywHLPYwcJsyGVN47JJRNid";
  let collection_name = 'PMPinternal';
  let collectionCacheFolder = "/AZ/API.old/Cache/PMP";

  // Step 1: Cache images 
  console.log("Caching " + collection_name + " Images...");
  for (var i=1; i<= total_supply; i++) {
    let image_ipfs_link_i = image_ipfs_link + i + ".png";
    image_ipfs_link_i = image_ipfs_link_i.replace("ipfs://","/ipfs/");
  
    let input_data = await database.Images.findOne({input:image_ipfs_link_i});
    if (input_data) continue;
    try {
      // let image_path = '/AZ/API.old/Cache/PMP/images/' + i + '.png';
      let image_path = `${collectionCacheFolder}/images/${i}.png`;
      let cloud_flare_image_custom_id = collection_name + '/nfts/' + i;
      let form = new FormData();
      form.append('file', fs.readFileSync(image_path), image_path);
      form.append('id', cloud_flare_image_custom_id);
      const {status, data} = await axios.post(
        'https://api.cloudflare.com/client/v4/accounts/' + process.env.CLOUDFLARE_ACCOUNT_ID + '/images/v1',
        form,
        {
            headers: {
                ...form.getHeaders(),
                'Authorization': 'Bearer ' + process.env.CLOUDFLARE_API_KEY
            }
        }
      );
      if (status == 200) {
        await database.Images.create({
          input:image_ipfs_link_i,
          isCloudFlare: true,
          location1440: 'https://imagedelivery.net/' + process.env.CLOUDFLARE_ACCOUNT_HASH + '/' + cloud_flare_image_custom_id + '/1440',
          location1920: 'https://imagedelivery.net/' + process.env.CLOUDFLARE_ACCOUNT_HASH + '/' + cloud_flare_image_custom_id + '/1920',
          location1024: 'https://imagedelivery.net/' + process.env.CLOUDFLARE_ACCOUNT_HASH + '/' + cloud_flare_image_custom_id + '/1024',
          location500: 'https://imagedelivery.net/' + process.env.CLOUDFLARE_ACCOUNT_HASH + '/' + cloud_flare_image_custom_id + '/500',
          location100: 'https://imagedelivery.net/' + process.env.CLOUDFLARE_ACCOUNT_HASH + '/' + cloud_flare_image_custom_id + '/100'
        });
        console.log('Cached image ' + i + '.png');
      } else {
        console.log('Cannot cache image ' + i + '.png.');
      }
    } catch (e){
      console.log(e);
    }
  }

  // Step 2: Cache jsons
  console.log("Caching " + collection_name + " Jsons...");
  for (var i=1; i<=total_supply; i++){

    let json_ipfs_link_i = json_ipfs_link + i + ".json";
    json_ipfs_link_i = json_ipfs_link_i.replace("ipfs://","/ipfs/");
    
    // if (!fs.existsSync("/AZ/API.old/Cache/PMP" + "/jsons/" + i + ".json")) {
    if (!fs.existsSync(`${collectionCacheFolder}/jsons/${i}.json`)) {
      console.log(`${collectionCacheFolder}/jsons/${i}.json` + ':File not exists.');
      continue
    }
    let input_data = await database.JSON.findOne({input:json_ipfs_link_i});
    if (input_data) continue;
  
    await database.JSON.create({
      input:json_ipfs_link_i,
      // location: "/AZ/API.old/Cache/PMP" + "/jsons/" + i + ".json"
      location: `${collectionCacheFolder}/jsons/${i}.json`
    });
    // console.log("/AZ/API/Cache/" + collection_name + "/jsons/" + i + ".json");
    console.log(`${collectionCacheFolder}/jsons/${i}.json`);
    console.log('added to JSON',json_ipfs_link_i);
  }

  // Step 3: Update NFT
  console.log("Update Request " + collection_name + " NFTs...");
  for (var i=1; i<=total_supply; i++){
    let queue_data = await database.NFTQueue.findOne({nftContractAddress:collection_address,tokenID:i});
    if (!queue_data){
      console.log('added to NFT queue',i);
      await database.NFTQueue.create({"type":"update",nftContractAddress:collection_address,tokenID:i});
    }
  }
});
