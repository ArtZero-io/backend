import dotenv from "dotenv";
import {Keyring} from "@polkadot/keyring";
import {KeyringPair$Json} from "@polkadot/keyring/types";
import fs from "fs";
dotenv.config();

import * as nft721_psp34_standard_calls from "../contracts/nft721_psp34_standard_calls";
import {ContractPromise} from "@polkadot/api-contract";
import {nft721_psp34_standard} from "../contracts/nft721_psp34_standard";
import {ApiPromise, WsProvider} from "@polkadot/api";
import jsonrpc from "@polkadot/types/interfaces/jsonrpc";
import {profile} from "../contracts/profile";
import * as profile_calls from "../contracts/profile_calls";
import {sleep} from "../utils/Tools";

const provider = new WsProvider(process.env.WSSPROVIDER_API);
let rpcStatus = false;
let api = new ApiPromise({
    provider,
    rpc: jsonrpc,
    types: {
        ContractsPsp34Id: {
            _enum: {
                U8: "u8",
                U16: "u16",
                U32: "u32",
                U64: "u64",
                U128: "u128",
                Bytes: "Vec<u8>",
            },
        },
    },
});
api.on("connected", () => {
    api.isReady.then(async () => {
        console.log("Smartnet Astar Connected");
        rpcStatus = true;
        await autoMintNftFromAdvanceMode();
    });
});

api.on("ready", () => {
    const profile_contract = new ContractPromise(
        api,
        profile.CONTRACT_ABI,
        profile.CONTRACT_ADDRESS
    );
    console.log('Profile Contract is ready');
    profile_calls.setContract(profile_contract);
});

api.on("error", (err) => {
    console.log('error', err);
});

export async function autoMintNftFromAdvanceMode() {
    const pathJson:string = process.env.JSON_CREATOR ? process.env.JSON_CREATOR : '';
    console.log(pathJson);
    if (!pathJson || pathJson.length == 0) {
        console.log(`Key not found!`);
        return;
    }
    const collectionAddress = "aXxP8A9Ei126JmgtRjdEmmrNWBTq8L3rsuv9MCxjG2SkEBK";

    const keyring = new Keyring({type: 'sr25519'});
    const keyJson = JSON.parse(fs.readFileSync(pathJson, { encoding: 'utf-8' })) as KeyringPair$Json;
    const keypair = keyring.addFromJson(keyJson);
    const caller = keypair.address;
    const urlUpdateNft = `https://astar-api.artzero.io/updateNFT`;
    keypair.decodePkcs8(process.env.KEY_PAIR);
    console.log({caller: caller});
    console.log({type: keypair.type});
    console.log({isLocked: keypair.isLocked});


    /**
     * Minting
     */
    const totalSupply = 100;
    if (caller) {
        const nft_contract = new ContractPromise(
            api,
            nft721_psp34_standard.CONTRACT_ABI,
            collectionAddress
        );
        for (let tokenId = 9; tokenId <= 9; tokenId++) {
            await nft721_psp34_standard_calls.mintNewNft(
                keypair,
                nft_contract,
                tokenId,
                urlUpdateNft,
                collectionAddress
            );

            await sleep(1000);
        }
    }
}

