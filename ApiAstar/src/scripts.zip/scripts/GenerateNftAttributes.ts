import dotenv from "dotenv";
import winston from "winston";
import fs from 'fs';
import {convertToUTCTime} from "../utils/Tools";
dotenv.config();

/**
 * logger.error("Error message");
 * logger.warn("Warning message");
 * logger.info("Info message");
 * logger.verbose("Verbose message");
 * logger.debug("Debug message");
 * logger.silly("Silly message");
 */
export const logger = winston.createLogger({
    level: "silly",
    format: winston.format.combine(
        winston.format.timestamp(), // adds a timestamp property
        winston.format.json()
    ),
    transports: [
        new winston.transports.Console(),
        new winston.transports.File({filename: "logs/scripts_error.log", level: "error"}),
        new winston.transports.File({filename: "logs/scripts_info.log", level: "info"}),
        new winston.transports.File({filename: "logs/scripts.log"}),
    ],
});

function camelize(str:string) {
    return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(word, index) {
        return index === 0 ? word.toLowerCase() : word.toUpperCase();
    }).replace(/\s+/g, '');
}
export async function generateNftAttributes() {
    const currentTime = convertToUTCTime(new Date());
    logger.info(`Start createNftQueue now: ${currentTime}`);
    /**
     * Config
     */
    const totalSupply = 100;
    let collectionName = "";
    let rootPath = `/Volumes/CharlesBox/Development/DataForDevOnly/AstarImagesMainnet/images_cache`;
    /**
     * Images
     */
    const ipfsUrlBear = `ipfs://bafybeicehhhbva2jsgo62oh3n7h72eu26mhmdnrntekdd27mlzadsbzday`;  // numberCollection = 1
    const ipfsUrlCat = `ipfs://bafybeih5qgpys6wotghhja72u3pj2f7sgb2e4suxtl5yyxquv27hjvvlgu`;   // numberCollection = 2
    const ipfsUrlFox = `ipfs://bafybeieb3q7na5ado2skvs6qv4dgck2esldfig2vilyxi7mvpvurj2d4sy`;   // numberCollection = 3
    /**
     * JSON
     * bear ipfs://bafybeidxhasbsoz4s3u76xiv2ftwwj24pberzpqxskj3bcdsgn2vlir2ou
     * fox ipfs://bafybeic6njp64kx2lvmvxfrstuozfuyp6s34lgjri4627xwltvqti5t5hm
     * cat ipfs://bafybeihlixg2fapnar7wgf5bwem5u4e7thi22aekd73z7be3zdqtt2wjlq
     */

    /**
     * Collection Name:
     * bear: bearAborigines
     * fox: japaneseFox
     * cat: funnyCatAndDog
     */

    /**
     * Collection Address:
     * bear:    YdutazaybnFDs2aK4JDVZZycExvU43CARSowwapxAXi6Cr9
     * fox:     aXxP8A9Ei126JmgtRjdEmmrNWBTq8L3rsuv9MCxjG2SkEBK
     * cat:     WLSpWC3w9g8Nb3qbPdaQRrc9robC5qgBnqat7EhWYVaXeXd
     */

    let ipfsUrl = "";
    let numberCollection:number = 1;
    /**
     * Processing
     * /ipfs/hash_string/
     */
    switch (numberCollection) {
        case 1:
            collectionName = "Bear Aborigines";
            ipfsUrl = ipfsUrlBear;
            break;
        case 2:
            collectionName = "Funny Cat and Dog";
            ipfsUrl = ipfsUrlCat;
            break;
        case 3:
            collectionName = "Japanese Fox";
            ipfsUrl = ipfsUrlFox;
            break
        default:
            return;
    }
    try {
        rootPath = `${rootPath}/${camelize(collectionName)}`;
        if (!fs.existsSync(`${rootPath}`)){
            fs.mkdirSync(`${rootPath}`);
        }
        if (!fs.existsSync(`${rootPath}/jsons`)){
            fs.mkdirSync(`${rootPath}/jsons`);
        }
        if (!fs.existsSync(`${rootPath}/images`)){
            fs.mkdirSync(`${rootPath}/images`);
        }
        for (let index= 1; index <= totalSupply; index++) {
            try {
                const pathJson = `${rootPath}/jsons/${index}.json`;
                const data:any = {};
                /**
                 * Create attributes
                 */
                let attributes:object[] = [];
                switch (numberCollection) {
                    case 1: // Bear Aborigines
                        const classData = ['Water', 'Wood', 'Earth', 'Metal'];
                        attributes.push({trait_type: "Class", value: `${classData[Math.floor(Math.random()*classData.length)]}`});
                        attributes.push({trait_type: "Breed Count", value: `${(Math.random() * (6 - 1) + 1).toFixed(0)}/6`});
                        attributes.push({trait_type: "Power", value: `${(Math.random() * (500 - 1) + 1).toFixed(0)}`});
                        attributes.push({trait_type: "Farming", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Level", value: `${Math.round(Math.random() * (100 - 1) + 1)}/100`});
                        attributes.push({trait_type: "Growth", value: `${(Math.random() * (24 - 1) + 1).toFixed(0)}`});
                        attributes.push({trait_type: "Star", value: `${Math.floor(Math.random() * (5 - 1) + 1)}`});
                        attributes.push({trait_type: "Speed", value: `${Math.round(Math.random() * 99) + 1}%`});
                        attributes.push({trait_type: "Hp", value: `${Math.round(Math.random() * 99) + 1}%`});
                        attributes.push({trait_type: "Armor", value: `${Math.round(Math.random() * 99) + 1}%`});
                        attributes.push({trait_type: "Magic level", value: `${Math.round(Math.random() * 99) + 1}%`});
                        attributes.push({trait_type: "Genes", value: `${Math.round(Math.random() * 99) + 1}%`});
                        attributes.push({trait_type: "Crit Dmg", value: `${Math.floor(Math.random() * 201)}%`});
                        attributes.push({trait_type: "Crit Rate", value: `${Math.floor(Math.random() * 101)}%`});
                        break;
                    case 2: // Funny Cat and Dog
                        attributes.push({trait_type: "Ambitious", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Frugal", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Tough", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Level", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Breezy", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Solemn", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Proud", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Pure", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Physical", value: `${Math.floor(Math.random() * 101)}%`});
                        break;
                    case 3: // Japanese Fox
                        attributes.push({trait_type: "Level", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Breezy", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Solemn", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Soft", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Stylish", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Formal", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Casual", value: `${Math.floor(Math.random() * 101)}%`});
                        attributes.push({trait_type: "Emotional", value: `${Math.floor(Math.random() * 101)}%`});
                        break;
                    default:
                        break;
                }

                /**
                 * Create other information:
                 * URL: ipfs://<CID>/<tokenID>.json
                 */
                data.date = new Date().getTime();
                data.name = `${collectionName} #${index}`;
                data.image = `${ipfsUrl}/${index}.png`;
                data.description = `#${index}`;
                data.dna = `#${index}`;
                data.edition = 1;
                data.attributes = attributes;
                /**
                 * Write data
                 */
                fs.writeFileSync(pathJson, JSON.stringify(data, null, 2), 'utf8');
                logger.info(`Data successfully saved to disk of ${index}.json`);
            } catch (e) {
                logger.error(e.messages);
            }
        }
    } catch (e) {
        logger.error(e.messages);
    }
}

generateNftAttributes().then();