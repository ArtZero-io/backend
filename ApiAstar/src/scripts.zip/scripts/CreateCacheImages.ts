import FormData from "form-data";
import fs from "fs";
import axios from "axios";
import dotenv from "dotenv";
import {send_telegram_message} from "../utils/utils";
dotenv.config();

export async function cacheImagesTmp(
    rootPath: string,
    total_supply: number,
    collection_name: string,
    tokenId: number
) {
    if (!tokenId) return;
    let image_path = `${rootPath}${collection_name}/images/${tokenId}.png`;
    let cloud_flare_image_custom_id = collection_name + '/nfts/' + tokenId;
    cloud_flare_image_custom_id = `astar/${cloud_flare_image_custom_id}`;
    // console.log(process.env.CLOUDFLARE_API_KEY);
    try {
        let form = new FormData();
        const url = `https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/images/v1`;
        console.log(`url: ${url}`);
        console.log(`image_path: ${image_path}`);
        console.log(`cloud_flare_image_custom_id: ${cloud_flare_image_custom_id}`);
        form.append('file', fs.readFileSync(image_path), image_path);
        form.append('id', cloud_flare_image_custom_id);
        const {status, data} = await axios.post(
            `${url}`,
            form,
            {
                headers: {
                    ...form.getHeaders(),
                    'Authorization': 'Bearer ' + process.env.CLOUDFLARE_API_KEY
                }
            }
        );
        if (status == 200) {
            console.log('Cached image ' + tokenId + '.png');
        } else {
            console.log('Cannot cache image ' + tokenId + '.png.');
        }
    } catch (e){
        console.log(e);
        if (e.response.status == 409) {
            console.log('Cached image ' + tokenId + ' exist on CloudFlare!');
            console.log('Updated image ' + tokenId + ' on CloudFlare!');
        } else {
            send_telegram_message("The image has error:" + cloud_flare_image_custom_id);
            console.log("Cache image has input " + tokenId + " false: " + e.message);
        }
    }
}
export async function cacheImages() {
    // Checking the configs before running
    // let rootPath = `/home/azero/htdocs/share_cache/Cache/`;
    let rootPath = `/Volumes/CharlesBox/Development/DataForDevOnly/AstarImagesMainnet/images_cache/`;
    let total_supply = 100;
    let collection_name = 'funnyCatAndDog';
    const listError:number[] = [];  // List TokenId Error
    const resolveError = false;

    // //Step 1: Cache images
    console.log("Caching " + collection_name + " Images...");
    if (resolveError) {
        for (let index= 0; index<= listError.length; index++) {
            await cacheImagesTmp(
                rootPath,
                total_supply,
                collection_name,
                listError[index]
            );
        }
    } else {
        for (let i= 1; i<= total_supply; i++) {
            await cacheImagesTmp(
                rootPath,
                total_supply,
                collection_name,
                i
            );
        }
    }
}

cacheImages();